package com.example.gradecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText quizMark= findViewById(R.id.quizes);
        EditText hwMark= findViewById(R.id.homeworks);
        EditText mtaMark= findViewById(R.id.MTAs);
        EditText finalMark= findViewById(R.id.finals);
        TextView results= findViewById(R.id.show_result);
        Button calculate= findViewById(R.id.calculate_button);
        Button reset= findViewById(R.id.reset_button);

        //reset action is easy
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quizMark.getText().clear();
                hwMark.getText().clear();
                mtaMark.getText().clear();
                finalMark.getText().clear();
                results.setText("Result");
                results.setTextColor(Color.parseColor("#009688"));
            }
        });

        //calculate button action
        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean anyEmpty= quizMark.getText().toString().length() == 0 ||
                        hwMark.getText().toString().length() == 0 ||
                        mtaMark.getText().toString().length() == 0 ||
                        finalMark.getText().toString().length() == 0;

                boolean invalidValues= Double.parseDouble(quizMark.getText().toString())>15.0 ||
                        Double.parseDouble(hwMark.getText().toString())>25.0 ||
                        Double.parseDouble(mtaMark.getText().toString())>30.0 ||
                        Double.parseDouble(finalMark.getText().toString())>30.0;

                if (anyEmpty)
                    Toast.makeText(MainActivity.this, "kindly, fill in all fields",
                            Toast.LENGTH_LONG).show();

                if(invalidValues)
                    Toast.makeText(MainActivity.this, "enter valid values", Toast.LENGTH_LONG).show();

                else{
                    double savedResult= Double.parseDouble(quizMark.getText().toString()) +
                            Double.parseDouble(hwMark.getText().toString()) +
                            Double.parseDouble(mtaMark.getText().toString()) +
                            Double.parseDouble(finalMark.getText().toString());

                    if(savedResult>=90.0 && savedResult<=100.0){
                        results.setText("A\t\t\t"+savedResult);
                        results.setTextColor(Color.parseColor("#388F3C"));
                    }
                    else if (savedResult>=80.0 && savedResult<90.0){
                        results.setText("B\t\t\t"+savedResult);
                        results.setTextColor(Color.parseColor("#2196F3"));
                    }
                    else if (savedResult>=70.0 && savedResult<80.0){
                        results.setText("C\t\t\t"+savedResult);
                        results.setTextColor(Color.parseColor("#FF9800"));
                    }
                    else if (savedResult>=60.0 && savedResult<70.0){
                        results.setText("D\t\t\t"+savedResult);
                        results.setTextColor(Color.parseColor("#FF0015"));
                    }
                    else if (savedResult>=0.0 && savedResult<60.0){
                        results.setText("F\t\t\t"+savedResult);
                        results.setTextColor(Color.parseColor("#000000"));
                    }
                }
            }
        });
    }
}